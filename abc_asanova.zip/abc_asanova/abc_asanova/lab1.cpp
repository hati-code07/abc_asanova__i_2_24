#include <iostream>
#include <string>
using namespace std;

// Функция для перевода числа из десятичной системы в другую систему счисления
    string convertToBase(int number, int base) {
    if (number == 0) return "0";
    
    // Обработка отрицательных чисел
    bool isNegative = false;
    if (number < 0) {
        isNegative = true;
        number = -number;
    }
    
    string result;
    while (number > 0) {
        int remainder = number % base;
        char digit = (remainder < 10) ? ('0' + remainder) : ('A' + (remainder - 10));
        result = digit + result;
        number /= base;
    }
    
    // Добавляем знак минус, если число было отрицательным
    if (isNegative) {
        result = "-" + result;
    }
    return result;
}

// Функция для проверки, является ли строка палиндромом
bool isPalindrome(const string& str) {
    int left = 0;
    int right = str.length() - 1;
    
    while (left < right) {
        if (str[left] != str[right]) {
            return false;
        }
        left++;
        right--;
    }
    return true;
}

int main() {
    int number;
    
    cout << "Введите число: ";
    cin >> number;
    
    // Переводим число в двоичную систему счисления
    string binaryNumber = convertToBase(number, 2);
    cout << "Число " << number << " в двоичной системе счисления: " << binaryNumber <<endl;
    
    // Проверяем, является ли число палиндромом в двоичной системе
    if (isPalindrome(binaryNumber)) {
        cout << "Это число является палиндромом в двоичной системе." <<endl;
    } else {
        cout << "Это число не является палиндромом в двоичной системе." <<endl;
    }
    
    return 0;
}



