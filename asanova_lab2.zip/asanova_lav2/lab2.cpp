#include <iostream>
#include <bitset>
#include <cstring>
using namespace std;

// Функция для преобразования float в битовое представление
uint32_t float_to_bits(float f) {
    uint32_t bits;
    memcpy(&bits, &f, sizeof(f));
    return bits;
}

// Функция для побитового сравнения двух чисел типа float
void compare_floats_bitwise(float a, float b) {
    uint32_t bits_a = float_to_bits(a);
    uint32_t bits_b = float_to_bits(b);

    bitset<32> bitset_a(bits_a);
    bitset<32> bitset_b(bits_b);

    cout << "Битовое представление числа a: " << bitset_a << endl;
    cout << "Битовое представление числа b: " << bitset_b << endl;

    cout << "Побитовое сравнение:" <<endl;
    for (int i = 31; i >= 0; --i) {
        bool bit_a = bitset_a[i];
        bool bit_b = bitset_b[i];

        cout << "Бит " << i << ": ";
        if (bit_a == bit_b) {
            cout << "Совпадают (" << bit_a << ")" << endl;
        } else {
            cout << "Различаются (a: " << bit_a << ", b: " << bit_b << ")" << endl;
        }
    }
}

int main() {
    float a = 123.456f;
    float b = 123.4567f;

    compare_floats_bitwise(a, b);

    return 0;
}
