//
//  lab2.hpp
//  abc_asanova
//
//  Created by Хатидже on 05.03.2025.
//

#ifndef lab2_hpp
#define lab2_hpp

#include <stdio.h>

#endif /* lab2_hpp */
