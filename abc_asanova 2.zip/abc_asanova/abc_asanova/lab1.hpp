//
//  lab1.hpp
//  abc_asanova
//
//  Created by Хатидже on 14.02.2025.
//

#ifndef lab1_hpp
#define lab1_hpp

#include <stdio.h>

#endif /* lab1_hpp */
